export interface ConvertToString {
  convertToString(): string;
}
